To change the load, the specific variable inside the code need to be altered here which is numElements which.

numElements= 50000
numElements= 50000 * 2
numElements= 50000 * 4
...
