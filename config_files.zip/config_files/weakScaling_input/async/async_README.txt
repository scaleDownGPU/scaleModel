To change the load, the specific variable inside the code need to be altered here which is n which.

n= 16 *1024 * 1024
n = 32 * 1024 * 1024
n = 64 * 1024 *1024
n = 128 * 1024 * 1024
n = 256 * 1024 * 1024
...
