To change the load, the specific variable inside the code need to be altered here which is OPT_N.

OPT_N= 4000000
OPT_N= 4000000 * 2
OPT_N= 4000000 * 4
OPT_N= 4000000 * 8
OPT_N= 4000000 * 16
...
